import mongoose from "mongoose";

const admissionSchema = new mongoose.Schema({
    patientId: { type: mongoose.Schema.Types.ObjectId, ref: "Patient", required: true },
    bedId: { type: mongoose.Schema.Types.ObjectId, ref: "Bed", required: true },
    admissionDate: { type: Date, default: Date.now },
    dischargeDate: { type: Date },
});

export default mongoose.model("Admission", admissionSchema);
