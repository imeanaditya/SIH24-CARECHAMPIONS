import express from "express";
import Admission from "admission.model.js";

const router = express.Router();

// Admit patient
router.post("/", async (req, res) => {
    try {
        const admission = new Admission(req.body);
        await admission.save();
        res.status(201).json(admission);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

// Discharge patient
router.put("/discharge/:id", async (req, res) => {
    try {
        const admission = await Admission.findByIdAndUpdate(req.params.id, {
            dischargeDate: Date.now()
        }, { new: true });
        res.status(200).json(admission);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

export default router;
