import mongoose from "mongoose";

const bedSchema = new mongoose.Schema({
    number: { type: Number, required: true, unique: true },
    status: { type: String, default: "available" }, // available, occupied
    patientId: { type: mongoose.Schema.Types.ObjectId, ref: "Patient" }, // linked to Patient model
});

export default mongoose.model("Bed", bedSchema);
