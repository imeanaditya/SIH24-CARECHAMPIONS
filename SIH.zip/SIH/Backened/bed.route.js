import express from "express";
import Bed from "bed.model.js";

const router = express.Router();

// Get all available beds
router.get("/", async (req, res) => {
    try {
        const beds = await Bed.find({ status: "available" });
        res.status(200).json(beds);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

// Assign a bed to a patient
router.put("/assign/:id", async (req, res) => {
    try {
        const bed = await Bed.findByIdAndUpdate(req.params.id, {
            status: "occupied",
            patientId: req.body.patientId
        }, { new: true });
        res.status(200).json(bed);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

export default router;
