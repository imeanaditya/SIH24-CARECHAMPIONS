import express from "express";
import mongoose from "mongoose";
import dotenv from "dotenv";
import cors from "cors";

// Importing newly created routes
import patientRoute from "patient.route.js";
import queueRoute from "queue.route.js";
import bedRoute from "bed.route.js";
import admissionRoute from "admission.route.js";

const app = express();

app.use(cors());
app.use(express.json());

dotenv.config();

const PORT = process.env.PORT || 4000;
const  URI = process.env.MongoDBURI;

// Connect to MongoDB
try {
    mongoose.connect(URI, {
        useNewUrlParser: true,
        useUnifiedTopology: true,
    });
    console.log("Connected to MongoDB");
} catch (error) {
    console.log("Error: ", error);
}

// Defining new routes for hospital management system
app.use("/patient", patientRoute);
app.use("/queue", queueRoute);
app.use("/bed", bedRoute);
app.use("/admission", admissionRoute);

app.listen(PORT, () => {
    console.log(`Server is listening on port ${PORT}`);
});
