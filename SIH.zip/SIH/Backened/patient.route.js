import express from "express";
import Patient from "patient.model.js";

const router = express.Router();

// Create new patient
router.post("/", async (req, res) => {
    try {
        const newPatient = new Patient(req.body);
        await newPatient.save();
        res.status(201).json(newPatient);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

// Get all patients
router.get("/", async (req, res) => {
    try {
        const patients = await Patient.find();
        res.status(200).json(patients);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

// Update patient status (admitted, discharged, etc.)
router.put("/:id", async (req, res) => {
    try {
        const updatedPatient = await Patient.findByIdAndUpdate(req.params.id, req.body, { new: true });
        res.status(200).json(updatedPatient);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

export default router;
