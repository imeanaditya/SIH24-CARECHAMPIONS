import mongoose from "mongoose";

const queueSchema = new mongoose.Schema({
    patientId: { type: mongoose.Schema.Types.ObjectId, ref: "Patient", required: true },
    queueTime: { type: Date, default: Date.now },
    status: { type: String, default: "waiting" }, // waiting, completed
});

export default mongoose.model("Queue", queueSchema);
