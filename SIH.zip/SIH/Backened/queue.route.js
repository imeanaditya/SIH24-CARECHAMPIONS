import express from "express";
import Queue from "queue.model.js";

const router = express.Router();

// Add patient to queue
router.post("/", async (req, res) => {
    try {
        const queueItem = new Queue(req.body);
        await queueItem.save();
        res.status(201).json(queueItem);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

// Get queue of waiting patients
router.get("/", async (req, res) => {
    try {
        const queue = await Queue.find({ status: "waiting" }).populate("patientId");
        res.status(200).json(queue);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

export default router;
