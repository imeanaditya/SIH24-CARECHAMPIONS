<?php
     $uname = $_POST['uname'];
     $uID = $_POST['uID'];
     $pno= $_POST['pno'];
     $email = $_POST['email'];
     $password = $_POST['password'];
     $password= $_POST['password'];
     $gender = $_POST['gender'];
     $DOB = $_POST['DOB'];
     $address = $_POST['address'];

     //database connection
     $con = new mysqli("localhost","myadmin","", "registeration");
     if ($con->connect_error) {
          die("connection failed :". $con->connect_error);
     }else{
          $stmt = $conn->prepare("insert into Registration(uname, uID, pno, email, password, gender, DOB, address)
          values(?,?,?,?,?,?,?,?)");
          $stmt->bind_param("sssssi", $uname, $uID, $pno, $email, $password, $gender, $DOB, $address);
          $stmt->execute();
          echo "Registered Successfully...";
          $stmt->close();
          $conn->close(); 
     }
?>