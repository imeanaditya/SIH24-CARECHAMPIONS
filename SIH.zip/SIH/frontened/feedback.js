// script.js
document.getElementById('feedbackForm').addEventListener('submit', function(event) {
    event.preventDefault();

    // Extract form data
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const message = document.getElementById('message').value;

    // For demonstration, we're just logging the data and showing a response message
    console.log('Name:', name);
    console.log('Email:', email);
    console.log('Message:', message);

    // Show a confirmation message
    document.getElementById('responseMessage').textContent = 'Thank you for your feedback! We will get back to you soon.';

    // Clear form
    document.getElementById('feedbackForm').reset();
});