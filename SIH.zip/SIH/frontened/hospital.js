document.getElementById("slotBookingForm").onsubmit = function(event) {
    event.preventDefault();

    var doctor = document.getElementById("doctor").value;
    var date = document.getElementById("date").value;
    var time = document.getElementById("time").value;

    if (doctor && date && time) {
        // Simulating a slot booking process
        var statusDiv = document.getElementById("bookingStatus");

        // Assuming all slots are available for simplicity
        statusDiv.innerHTML = "Slot successfully booked with " + doctor + " on " + date + " at " + time;
        statusDiv.style.color = "green";
    } else {
        // If any field is empty
        statusDiv.innerHTML = "Please fill out all fields.";
        statusDiv.style.color = "red";
    }
};
