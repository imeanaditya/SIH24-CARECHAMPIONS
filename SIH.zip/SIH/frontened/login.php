<?php
     
     $email = $_POST['email'];
     $password = $_POST['password'];
     

     //database connection
     $con = new mysqli("localhost","root","", "test");
     if ($con->connect_error) {
          die("connection failed :". $con->connect_error);
     }else{
          $stmt = $conn->prepare("select * from registration where email = ?");
          
          $stmt->bind_param("s", $email);
          $stmt->execute();
          $stmt_result = $stmt ->get_result();
          if($stmt_result->num_rows > 0){
            $data = $stmt_result->fetch_assoc();
            if($data["password"] === $password){
                echo "Registered Successfully...";
            }else{
                echo "Invalid Email and Password";
            }
          }else{
            echo "Invalid Email and Password ";
        //   $stmt->close();
        //   $conn->close(); 
     }
?>