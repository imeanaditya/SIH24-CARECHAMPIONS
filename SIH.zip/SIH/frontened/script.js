function validateform(){  
    var username=document.getElementById("uname").value;  
    var password=document.getElementById("pws").value;  
      
    if (username=="" || password==""){  
      alert("All fields must not be blanked");  
      return false;  }
      else if(username.length <6 || !isNaN(username)){
        alert("Name should contain Alphabets and the length should not be less than 6 characters");  
        return false;
      }
      else if(password.length<6){  
      alert("Password should not be less than 6 characters long");  
      return false;  
      }  
    }  
    